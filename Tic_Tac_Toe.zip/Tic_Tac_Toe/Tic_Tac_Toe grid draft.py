import tkinter as tk


# Create main window
root = tk.Tk()
root.title("Single Player Tic Tac Toe - Grid Only")
root.geometry("400x400")  # Enough space for 3x3 grid

# Create a frame to center the grid
grid_frame = tk.Frame(root)
grid_frame.pack(expand=True)

# Create 3x3 grid of buttons
buttons = []

for i in range(3):
    row = []
    for j in range(3):
        btn = tk.Button(grid_frame, text="", width=10, height=4, font=('Arial', 16))
        btn.grid(row=i, column=j, padx=5, pady=5)
        row.append(btn)
    buttons.append(row)

root.mainloop()

