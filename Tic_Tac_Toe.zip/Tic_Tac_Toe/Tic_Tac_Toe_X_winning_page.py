#imports modules
import numpy as np
import random
from time import sleep as sp
import os
import tkinter as tk
from tkinter import messagebox
import pygame
from PIL import Image, ImageTk
import time

root = tk.Tk()
root.title("Player X win's")
root.geometry("300x350")

#The logo in the top corner
logo = tk.PhotoImage(file="Logo.png")
root.iconphoto(False, logo)

#The x image
x_img = Image.open("x_image.png").resize((200,200))
x_img = ImageTk.PhotoImage(x_img)

X_Image_Label=tk.Label(root, image=x_img)
X_Image_Label.place(relx=0.5,rely=0.7,anchor="center")

# Background image
bg_image = Image.open("background.png")
bg_resized = bg_image.resize((600, 700))
bg_photo = ImageTk.PhotoImage(bg_resized)
background_label = tk.Label(root, image=bg_photo)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
background_label.image = bg_photo
background_label.lower()

#Creates a label for text
X_Wins_label=tk.Label(root, text="Congratulations", bg="#f5ece1", fg="red", font=('Arial', 28, "bold"))
X_Wins_label.place(relx=0.5,rely=0.1,anchor="center")
X_Wins_label2=tk.Label(root, text="🎉player X Wins🎉", bg="#f5ece1", fg="red", font=('Arial', 25, "bold"))
X_Wins_label2.place(relx=0.5,rely=0.3,anchor="center")

root.mainloop()