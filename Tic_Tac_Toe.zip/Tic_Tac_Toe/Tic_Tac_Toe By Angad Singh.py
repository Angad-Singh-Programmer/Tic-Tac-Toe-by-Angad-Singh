#imports modules
import numpy as np
import random
from time import sleep as sp
import os
import tkinter as tk
from tkinter import messagebox
import pygame
from PIL import Image, ImageTk
import time

# Initialize pygame mixer and play background music
pygame.mixer.init()
pygame.mixer.music.load("Background_music.wav")
pygame.mixer.music.play(-1)
pygame.mixer.music.set_volume(0.5)  # Start at 50% volume

# Tkinter root window
root = tk.Tk()
root.title("By Angad Singh")

logo = tk.PhotoImage(file="Logo.png")
root.iconphoto(False, logo)
root.geometry("600x700")

# Background image
bg_image = Image.open("background.png")
bg_resized = bg_image.resize((600, 700))
bg_photo = ImageTk.PhotoImage(bg_resized)
background_label = tk.Label(root, image=bg_photo)
background_label.place(x=0, y=0, relwidth=1, relheight=1)
background_label.image = bg_photo
background_label.lower()

Tic_Tac_Toe_label=tk.Label(root, text="Tic Tac Toe", bg="#f5ece1", font=('Arial', 28, "bold"))
Tic_Tac_Toe_label.place(relx=0.5,rely=0.04,anchor="center")

# Load X and O images
x_img = Image.open("x_image.png").resize((120, 120))
x_img = ImageTk.PhotoImage(x_img)
o_img = Image.open("o_image.png").resize((120, 120))
o_img = ImageTk.PhotoImage(o_img)

#The draw page
def draw_page():
    popup =tk.Toplevel(root)
    popup.title("Draw!")
    popup.iconphoto(False, logo)
    popup.geometry("300x350")
    popup.configure(bg="#f5ece1")
    popup.attributes("-topmost", True)

    draw_label = tk.Label(popup, text="It's a Draw!", font=("Arial", 18, "bold"), fg="black", bg="#f5ece1")
    draw_label.pack(pady=10)

    draw_img = Image.open("Draw_Image.png")
    draw_img = draw_img.resize((350, 350), Image.LANCZOS)
    draw_img = ImageTk.PhotoImage(draw_img)

    image_label = tk.Label(popup, image=draw_img, bg="#f5ece1")
    image_label.image = draw_img
    image_label.pack()

    popup.after(4000, popup.destroy)

#X Winning page
def x_page():
    popup =tk.Toplevel(root)
    popup.title("Player X Wins!")
    popup.iconphoto(False, logo)
    popup.geometry("300x350")
    popup.configure(bg="#f5ece1")
    popup.attributes("-topmost", True)

    x_img = Image.open("x_image.png")
    x_img = x_img.resize((200,200), Image.LANCZOS)
    x_img = ImageTk.PhotoImage(x_img)

    X_Image_Label=tk.Label(popup, image=x_img)
    X_Image_Label.image=x_img
    X_Image_Label.place(relx=0.5,rely=0.7,anchor="center")

    X_Wins_label=tk.Label(popup, text="Congratulations", bg="#f5ece1", fg="red", font=('Arial', 28, "bold"))
    X_Wins_label.place(relx=0.5,rely=0.1,anchor="center")
    X_Wins_label2=tk.Label(popup, text="🎉player X Wins🎉", bg="#f5ece1", fg="red", font=('Arial', 25, "bold"))
    X_Wins_label2.place(relx=0.5,rely=0.3,anchor="center")

    popup.after(4000, popup.destroy)


#O Winning page
def o_page():
    popup =tk.Toplevel(root)
    popup.title("Player O Wins!")
    popup.iconphoto(False, logo)
    popup.geometry("300x350")
    popup.configure(bg="#f5ece1")
    popup.attributes("-topmost", True)

    o_img = Image.open("o_image.png")
    o_img = o_img.resize((200,200), Image.LANCZOS)
    o_img = ImageTk.PhotoImage(o_img)

    o_Image_Label=tk.Label(popup, image=o_img)
    o_Image_Label.image=o_img
    o_Image_Label.place(relx=0.5,rely=0.7,anchor="center")


    o_Wins_label=tk.Label(popup, text="Congratulations", bg="#f5ece1", fg="red", font=('Arial', 28, "bold"))
    o_Wins_label.place(relx=0.5,rely=0.1,anchor="center")
    o_Wins_label2=tk.Label(popup, text="🎉player O Wins🎉", bg="#f5ece1", fg="red", font=('Arial', 25, "bold"))
    o_Wins_label2.place(relx=0.5,rely=0.3,anchor="center")

    popup.after(4000, popup.destroy)



# Game frame
game_frame = tk.Frame(root, width=450, height=450, bg="#9e9e9e")
game_frame.place(relx=0.5, rely=0.4, anchor="center")
game_frame.grid_propagate(False)

for i in range(3):
    game_frame.grid_rowconfigure(i, weight=1, uniform="row")
    game_frame.grid_columnconfigure(i, weight=1, uniform="column")

player = "x"
game_mode="2 player"

# Play sound effect
def play_sound(music):
    try:
        pygame.mixer.music.pause()
        current_volume = pygame.mixer.music.get_volume()
        sound = pygame.mixer.Sound(music)
        sound.set_volume(current_volume)
        sound.play()
        time.sleep(sound.get_length())
        pygame.mixer.music.unpause()
    except Exception as e:
        print("Error playing sound:", e)



# Check winner logic
def check_winner():
    for i in range(3):
        if buttons[i][0].player == buttons[i][1].player == buttons[i][2].player != "":
            return buttons[i][0].player
        if buttons[0][i].player == buttons[1][i].player == buttons[2][i].player != "":
            return buttons[0][i].player
    if buttons[0][0].player == buttons[1][1].player == buttons[2][2].player != "":
        return buttons[0][0].player
    if buttons[0][2].player == buttons[1][1].player == buttons[2][0].player != "":
        return buttons[0][2].player
    for row in buttons:
        for btn in row:
            if btn.player == "":
                return None
    return "draw"




# Reset board
def reset_board():
    global player
    player = "x"
    for i in range(3):
        for j in range(3):
            buttons[i][j]["image"] = ""
            buttons[i][j].player = ""

# Quit game
def Quit_board():
    root.quit()

# Volume control functions
def mute_music():#mute funtion
    pygame.mixer.music.set_volume(0.0)

def max_music():#max funtion
    pygame.mixer.music.set_volume(1.0)

def volume_up():#volume up funtion
    current_volume = round(pygame.mixer.music.get_volume(),1)
    new_volume = min(1.0, round(current_volume + 0.1,1))
    pygame.mixer.music.set_volume(new_volume)

def volume_down():#volume down funtion
    current_volume = round(pygame.mixer.music.get_volume(),1)
    new_volume = max(0.0, round(current_volume - 0.1,1))
    pygame.mixer.music.set_volume(new_volume)

# Update volume label
def update_volume_label():#volume label funtion
    current_volume = int(pygame.mixer.music.get_volume() * 100)
    volume_label.config(text=f"Vol: {current_volume}%")
    root.after(500, update_volume_label)


#The AI
def AI_move():
    empty_cells=[(i,j) for i in range(3) for j in range(3) if buttons[i][j].player==""]
    if empty_cells:
        i,j= random.choice(empty_cells)
        button_click(i,j)


def AI_turn():
    global player
    AI_move()
    winner = check_winner()
    if winner:
        if winner == "draw":
            play_sound("draw_sound.wav")
            root.after(100,draw_page)
        elif winner == "o":
            play_sound("Victory_Sound.wav")
            root.after(100,o_page)
        reset_board
    else:
        player="x"


# Button click handler
def button_click(i, j):
    global player
    if buttons[i][j].player == "":
        buttons[i][j]["image"] = x_img if player == "x" else o_img
        buttons[i][j].player = player
        winner = check_winner()
        if winner:
            if winner == "draw":
                play_sound("draw_sound.wav")
                root.after(100,draw_page)
            else:
                play_sound("Victory_Sound.wav")
                if winner=="x":
                    root.after(100,x_page)
                else:
                    root.after(100,o_page)
            reset_board()
        else:
            if game_mode == "1 player":
                if player=="x":
                    player="o"
                    root.after(100, AI_turn)
            else:
                player="o" if player =="x" else "x"



# Create buttons grid
buttons = []
for i in range(3):
    row = []
    for j in range(3):
        btn = tk.Button(game_frame, image="", command=lambda i=i, j=j: button_click(i, j), width=120, height=120, bd=0, highlightthickness=0)
        btn.grid(row=i, column=j, padx=5, pady=5)
        btn.player = ""
        row.append(btn)
    buttons.append(row)

# Control buttons
reset_btn = tk.Button(root, text="Reset", font=('Arial', 20), background="#9e9e9e", command=reset_board)
reset_btn.place(x=150, y=585, anchor="center")

quit_btn = tk.Button(root, text=" Quit ", font=('Arial', 20), background="#9e9e9e", command=Quit_board)
quit_btn.place(x=300, y=585, anchor="center")

# Music control buttons
vol_down_btn = tk.Button(root, text="🔈", font=('Arial', 12), background="#9e9e9e", command=volume_down)
vol_down_btn.place(x=540, y=100)

vol_up_btn = tk.Button(root, text="🔉", font=('Arial', 12), background="#9e9e9e", command=volume_up)
vol_up_btn.place(x=540, y=50)

mute_btn = tk.Button(root, text="🔇", font=('Arial', 12), background="#9e9e9e", command=mute_music)
mute_btn.place(x=540, y=150)

max_btn = tk.Button(root, text="🔊", font=('Arial', 12), background="#9e9e9e", command=max_music)
max_btn.place(x=540, y=200)

# Volume label
volume_label = tk.Label(root, text="Vol: 50%", bg="#9e9e9e", font=('Arial', 10))
volume_label.place(x=530, y=20)
update_volume_label()

# Gamemode label
gamemode_label=tk.Label(root, text=f"{game_mode}", bg="#9e9e9e", font=('Arial', 10))
gamemode_label.place(x=535, y=250)

#toggle gamemodes
def toggle_mode():
    global game_mode
    if game_mode=="2 player":
        game_mode="1 player"
        player_btn.config(text="2 player")
        gamemode_label.config(text="1 player")
        
    else:
        game_mode="2 player"
        player_btn.config(text="1 player")
        gamemode_label.config(text="2 player")
    
#The gamemode button
player_btn = tk.Button(root, text="1 player", font=('Arial', 20), background="#9e9e9e", command=toggle_mode)
player_btn.place(x=450, y=585, anchor="center")


root.mainloop()