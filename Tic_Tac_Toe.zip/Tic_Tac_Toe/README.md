
# 🎮 Tic Tac Toe Game using Python & Tkinter

A fun and interactive **Tic Tac Toe** game developed in Python using the **Tkinter GUI library**, enhanced with **images**, **sound effects**, and **background music** for an engaging experience.

---

## 🧩 Features

- 🎨 **Graphical Interface**: Custom-designed GUI with background images, logo, and game graphics.
- 🧠 **Two Modes**:
  - `2 Player` mode – play with a friend on the same device.
  - `1 Player` mode – play against a simple AI opponent.
- 🔊 **Audio Effects**:
  - Background music using `pygame.mixer`.
  - Victory and draw sound effects for game outcomes.
  - Volume controls: 🔈🔉🔊🔇 (up, down, mute, max).
- 🖼️ **Custom Graphics**:
  - X and O represented by themed images.
  - Winning and draw screens pop up with celebratory messages.
- 🔁 **Game Controls**:
  - Reset button to restart the game.
  - Quit button to close the game.

---

## 🖥️ Tech Stack

- **Python 3**
- **Tkinter** (for GUI)
- **Pygame** (for music and sound effects)
- **Pillow (PIL)** (for image processing)
- **NumPy** and **random** (used for AI and other logic)
- **Time**(for delay)

---

## 📁 Project Structure

```
TicTacToe/
├── main.py                  # Main Python game file
├── Background_music.wav     # Background music file
├── draw_sound.wav           # Sound played on draw
├── Victory_Sound.wav        # Sound played on win
├── x_image.png              # Image for player X
├── o_image.png              # Image for player O
├── background.png           # Background image
├── Logo.png                 # App icon/logo
├── Draw_Image.png           # Image for draw screen
├── README.md                # Project description (you are reading it)
```

---

## 🚀 How to Run

1. **Install Python 3** and required libraries:
   ```bash
   pip install pygame pillow numpy
   ```

2. **Run the game**:
   ```bash
   python main.py
   ```

---

## 📦 Uploading to GitHub

1. Create a repository on GitHub.
2. Initialize your folder as a Git repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Tic Tac Toe game"
   git remote add origin https://github.com/yourusername/tictactoe.git
   git push -u origin main
   ```

---

## 🏆 Credits

Created by **Angad Singh**.  
Designed for fun and learning with a personalized touch of visuals and sound.
